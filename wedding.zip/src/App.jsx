import { useState } from 'react'
import reactLogo from './assets/react.svg'
import Bunga1 from './assets/bunga1.png'
import Bunga2 from './assets/bunga2.png'
import Bunga3 from './assets/bunga3.png'
import Bunga4 from './assets/bunga4.png'
import Bunga5 from './assets/bunga5.png'
import Bunga6 from './assets/bunga6.png'
import Bunga7 from './assets/bunga7.png'
import Bunga8 from './assets/bunga8.png'
import Bunga9 from './assets/bunga9.png'
import Bunga10 from './assets/bunga10.png'
import Bunga11 from './assets/bunga11.png'
import bgBunga from './assets/bgbunga.png'
import  "./App";

function App() {


  return (
  
    <div className="h-screen flex items-center justify-center">
      <div className='h-[100%] w-[517px] absolute bg-white' 
      style={{background :'radial-gradient(circle, rgba(255,255,255,1) 0%,rgba(244,239,235,1) 100%)'}}>
          <img src={Bunga10} alt="" className='absolute top-0 right-0 z-0 w-[350px]'  />
          <img src={bgBunga} alt="" className='absolute bottom-0 left-0 z-0 w-[350px]' />
        <div>
          <img src={Bunga8} alt="ranting" className= 'absolute    left-[120px]  transform rotate-270   w-[380px] top-[-60px]' />
          <img src={Bunga8} alt="ranting kiri" className= 'absolute    left-[-80px]  transform rotate-90   w-[320px] top-[-60px]' />
          <img src={Bunga6} alt="bunga samping" className= 'absolute    left-[-30px]  transform rotate-270   w-[300px] top-[-40px]' />
          <img src={Bunga9} alt="pisang" className='absolute top-[-70px] right-0 z-0 left-[90px] w-[300px]' />
          <img src={Bunga5} alt="pucat" className='absolute top-0  w-[70px] left-[40px]'/>
          <img src={Bunga11} alt="bunga lebar" className= 'absolute   left-[30px]   -rotate-[55deg]   w-[280px] top-[-40px]' />
          <img src={Bunga7} alt="kuning" className='absolute top-0  w-[80px] left-[130px]'/>
        </div>
        
         <div class="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
          <img src={Bunga8} alt="Ranting" className='absolute  top-[80px] w-[180px] left-[-160px] rotate-[20deg]'/>
          <img src={Bunga11} alt="Bunga lebar" className='absolute  w-[180px] left-[-160px] -rotate-[145deg] '/>
            <h5 className='text-center font-poppins'>
              SAVE THE DATE
            </h5>
            <h4 className='text-center text-3xl font-poppins my-3'>THE WEDDING OF</h4>
            <h3 className='text-center text-5xl font-bold my-6 font-great tracking-wider '>Zefta & Ani</h3>
            <h4 className='text-center text-3xl font-poppins my-3'>MAR | 17 | 2023</h4>
          <img src={Bunga8} alt="Ranting" className='absolute  top-[80px] w-[180px] right-[-150px] -rotate-[220deg] transform scale-x-(-1)'/>
          <img src={Bunga11} alt="Bunga lebar" className='absolute top-[20px] w-[180px] right-[-160px] -rotate-[330deg] transform scale-x-(-1)'/>
         </div>

        <div>
          <img src={Bunga6} alt="bunga samping" className= 'absolute    right-[-70px]  transform rotate-[50deg]   w-[260px] bottom-[100px]' />

        </div>

        <div>
          <img src={Bunga8} alt="ranting kanan" className= 'absolute    left-[100px]  transform rotate-[320deg]   w-[380px] bottom-[-60px]' />
          <img src={Bunga6} alt="bunga samping" className= 'absolute    left-[-50px]  transform rotate-270   w-[300px] bottom-[-40px]' />
          <img src={Bunga9} alt="pisang" className='absolute bottom-[-70px] right-0 z-0 left-[90px] w-[300px] rotate-[260deg]' />
          <img src={Bunga5} alt="pucat" className='absolute bottom-0  w-[70px] left-[40px]'/>
          <img src={Bunga11} alt="bunga lebar" className= 'absolute   left-[30px]   -rotate-[240deg]   w-[280px] bottom-[-40px]' />
          <img src={Bunga7} alt="kuning" className='absolute bottom-0  w-[80px] left-[130px]'/>
        </div> 
      </div>
      <div className='h-[100%] w-[517px] bg-slate-500 absolute top-[100%]'>
      <img src={Bunga6} alt="" />

      </div>
      <div className='h-[100%] w-[517px] bg-slate-400 absolute top-[200%]'></div>
    </div>
  )
}

export default App
